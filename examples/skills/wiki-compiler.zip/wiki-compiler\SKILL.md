# wiki-compiler

从对话历史中提炼新知识，自动写入 Wiki 知识库。

## 触发条件

在对话结束后（session TTL 到期或显式触发）调用此 Skill，将有价值的知识沉淀到 Wiki。

## 参数说明

| 参数 | 类型 | 必填 | 说明 |
|------|------|------|------|
| conversation | array | 是 | 对话历史，格式：`[{role, content}]` |
| namespace | string | 是 | 目标 Wiki namespace（如 "product"） |
| wiki_mcp_url | string | 否 | Wiki MCP Server 地址，默认 `http://localhost:3001` |

## 输出格式

```json
{
  "updated_pages": ["faq/refund.md"],
  "summary": "提炼了 1 条退款相关知识"
}
```

## 使用示例

在 Context 的 Skill 配置中启用此 Skill，配置 `params.namespace` 为目标知识库。

建议配合 Scheduled Task 定时触发，或在 Bot 对话结束后手动调用。

## 注意事项

- 需要 Wiki MCP Server 正在运行
- 脚本执行超时默认 60 秒
- **当前版本使用启发式规则**（回答长度 > 100 字符）判断是否有新知识，适合快速验证。生产环境建议将 `index.js` 中的 `extractKnowledge` 函数替换为 LLM 调用（如 OpenAI/Anthropic API），以获得更准确的知识提炼效果。
