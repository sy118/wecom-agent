#!/usr/bin/env node
// wiki-compiler: 从对话历史提炼知识写入 Wiki

import { createInterface } from 'readline'
import { request } from 'http'

async function readStdin() {
  const rl = createInterface({ input: process.stdin })
  return new Promise((resolve) => {
    let data = ''
    rl.on('line', (line) => { data += line })
    rl.on('close', () => resolve(JSON.parse(data)))
  })
}

async function callWikiAppend(wikiMcpUrl, path, content, namespace) {
  const baseUrl = wikiMcpUrl || 'http://localhost:3001'
  return new Promise((resolve, reject) => {
    const body = JSON.stringify({
      jsonrpc: '2.0', id: 1, method: 'tools/call',
      params: { name: 'wiki_append', arguments: { path, content, namespace } },
    })
    const url = new URL('/messages', baseUrl)
    const req = request({ hostname: url.hostname, port: url.port, path: url.pathname, method: 'POST',
      headers: { 'Content-Type': 'application/json', 'Content-Length': Buffer.byteLength(body) },
    }, (res) => {
      let data = ''
      res.on('data', (chunk) => { data += chunk })
      res.on('end', () => resolve(JSON.parse(data)))
    })
    req.on('error', reject)
    req.write(body)
    req.end()
  })
}

async function extractKnowledge(conversation, namespace) {
  // Simple heuristic: look for Q&A pairs with substantive answers
  const pairs = []
  for (let i = 0; i < conversation.length - 1; i++) {
    const msg = conversation[i]
    const next = conversation[i + 1]
    if (msg.role === 'user' && next.role === 'assistant') {
      const userText = typeof msg.content === 'string' ? msg.content : ''
      const assistantText = typeof next.content === 'string' ? next.content : ''
      // Skip short or generic responses
      if (assistantText.length > 100 && !assistantText.includes('抱歉') && !assistantText.includes('无法')) {
        pairs.push({ question: userText, answer: assistantText })
      }
    }
  }
  return pairs
}

async function main() {
  const input = await readStdin()
  const { conversation = [], namespace = 'general', wiki_mcp_url } = input

  const pairs = await extractKnowledge(conversation, namespace)

  if (pairs.length === 0) {
    process.stdout.write(JSON.stringify({ updated_pages: [], summary: '无新知识' }))
    return
  }

  const updatedPages = []
  for (const pair of pairs) {
    const slug = pair.question.slice(0, 30).replace(/[^\w一-龥]/g, '-').replace(/-+/g, '-')
    const pagePath = `auto/${Date.now()}-${slug}`
    const content = `## Q: ${pair.question}\n\n${pair.answer}\n`
    try {
      await callWikiAppend(wiki_mcp_url, pagePath, content, namespace)
      updatedPages.push(`${pagePath}.md`)
    } catch (err) {
      process.stderr.write(`wiki_append failed: ${err.message}\n`)
    }
  }

  process.stdout.write(JSON.stringify({
    updated_pages: updatedPages,
    summary: `提炼了 ${updatedPages.length} 条知识到 namespace "${namespace}"`,
  }))
}

main().catch((err) => {
  process.stderr.write(`wiki-compiler error: ${err.message}\n`)
  process.stdout.write(JSON.stringify({ updated_pages: [], summary: `错误: ${err.message}` }))
})
